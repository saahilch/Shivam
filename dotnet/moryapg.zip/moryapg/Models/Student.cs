namespace App.Models;

public class Student
{
    public int Id{get; set;}
    public string Name{get;set;}
    public string Email{get;set;}
    public string RoomNo{get;set;}
    public double Fees{get;set;}
    public DateTime Date{get; set;}
}
