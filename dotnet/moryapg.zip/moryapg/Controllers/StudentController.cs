using System.Diagnostics;
using App.Models;
using App.Service;
using Microsoft.AspNetCore.Mvc;
using moryapg.Models;

namespace moryapg.Controllers;

public class StudentController : Controller
{
    public Disconnected _ds;

    public StudentController()
    {
        _ds=new Disconnected();
    }

    public IActionResult Index()
    {
        List<Student> students=_ds.GetAll();
        return View(students);
    }
    
    public IActionResult Details(int id)
    {
        Student student=_ds.GetById(id);
        return View(student);
    }

    public IActionResult Edit(int id)
    {
        Student student=_ds.GetById(id);
        return View(student);
    }

    [HttpPost]
    public IActionResult Edit(Student s)
    {
        _ds.Edit(s);
        return RedirectToAction("Index");
    }
    
    public IActionResult Add()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Add(Student s)
    {
        Console.WriteLine(s.Name);
        _ds.Add(s);
        return RedirectToAction("Index");
    }

    public IActionResult Delete(int id)
    {
        _ds.Delete(id);
        return RedirectToAction("Index");
    }
    
}
