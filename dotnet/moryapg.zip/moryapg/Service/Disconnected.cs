using System.Data;
using App.Models;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;

namespace App.Service;

public class Disconnected
{
    MySqlConnection connection;

    public Disconnected()
    {
        connection = new MySqlConnection(@"server=localhost; port=3306; user=root; password=root123; database=dotnet;");
    }
    public List<Student> GetAll()
    {
        MySqlCommand cmd = new MySqlCommand("select * from moryapg");
        cmd.Connection = connection;
        List<Student> students = new List<Student>();
        try
        {
            DataSet ds = new DataSet();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            DataRowCollection rows = dt.Rows;
            foreach (DataRow row in rows)
            {
                int id = int.Parse(row["Id"].ToString());
                string name = row["Name"].ToString();
                string email = row["Email"].ToString();
                string roomNo = row["RoomNo"].ToString();
                double fees = double.Parse(row["Fees"].ToString());
                DateTime date = DateTime.Parse(row["Date"].ToString());
                students.Add(new Student { Id = id, Name = name, Email = email, RoomNo = roomNo, Fees = fees, Date = date });
            }

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        return students;
    }

    public Student GetById(int eid)
    {
        MySqlCommand cmd = new MySqlCommand("select * from moryapg where id=" + eid);
        cmd.Connection = connection;
        Student students = null;
        try
        {
            DataSet ds = new DataSet();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            MySqlCommandBuilder bd = new MySqlCommandBuilder(da);
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            DataRow []d=dt.Select("Id="+eid);
            DataRow row=d[0];
            int id = int.Parse(row["Id"].ToString());
            string name = row["Name"].ToString();
            string email = row["Email"].ToString();
            string roomNo = row["RoomNo"].ToString();
            double fees = double.Parse(row["Fees"].ToString());
            DateTime date = DateTime.Parse(row["Date"].ToString());
            students=new Student { Id = id, Name = name, Email = email, RoomNo = roomNo, Fees = fees, Date = date };

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        return students;
    }

    public void Edit(Student s)
    {
        MySqlCommand cmd = new MySqlCommand("select * from moryapg where id=" + s.Id);
        cmd.Connection = connection;
        try
        {
            DataSet ds = new DataSet();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            MySqlCommandBuilder bd = new MySqlCommandBuilder(da);
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            DataRow []d=dt.Select("Id="+s.Id);
            DataRow row=d[0];
            row["Id"]=s.Id;
            row["Name"]=s.Name;
            row["Email"]=s.Email;
            row["RoomNo"]=s.RoomNo;
            row["Fees"]=s.Fees;
            row["Date"]=s.Date;
            
            da.Update(ds);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
    }

     public void Add(Student s)
    {
        MySqlCommand cmd = new MySqlCommand("select * from moryapg ");
        cmd.Connection = connection;
        try
        {
            DataSet ds = new DataSet();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            MySqlCommandBuilder bd = new MySqlCommandBuilder(da);
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            DataRow row=dt.NewRow();
            row["Id"]=s.Id;
            row["Name"]=s.Name;
            row["Email"]=s.Email;
            row["RoomNo"]=s.RoomNo;
            row["Fees"]=s.Fees;
            row["Date"]=s.Date;
            dt.Rows.Add(row);
            da.Update(ds);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
    }

    public void Delete(int eid)
    {
        MySqlCommand cmd = new MySqlCommand("select * from moryapg where id=" + eid);
        cmd.Connection = connection;
        try
        {
            DataSet ds = new DataSet();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            MySqlCommandBuilder bd = new MySqlCommandBuilder(da);
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            DataRow []d=dt.Select("Id="+eid);
            DataRow row=d[0];
            row.Delete();
            
            da.Update(ds);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
    }
}
